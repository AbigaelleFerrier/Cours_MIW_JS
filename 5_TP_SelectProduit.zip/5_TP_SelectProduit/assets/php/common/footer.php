<footer>
    <p>Cirill Ferrier - MIW 2019/2020</p>
    <?php include 'assets/img/svg/sprite.svg'?>
</footer>