<div class="navLike">
    <div>
        <input id="burger" type="checkbox" />
        <label for="burger">
            <span></span>
            <span></span>
            <span></span>
        </label>

        <h2>Titre inutile</h2>

        <nav>
            <div><a href="#">Link #0</a></div>
            <div><a href="#">Link #1</a></div>
            <div><a href="#">Link #2</a></div>
            <div><a href="#">Link #3</a></div>
            <div><a href="#">Link #4</a></div>
            <div><a href="#">Link #5</a></div>
            <div><a href="#">Link #6</a></div>
            <div><a href="#">Link #7</a></div>
            <div><a href="#">Link #8</a></div>
            <div><a href="#">Link #9</a></div>
        </nav>
    </div>

    <span class="navIcon">
        <a href="https://github.com/FerrierCirill/MorpionJS/tree/master/5_TP_SelectProduit">
            <svg class="icon"><use xlink:href="#github"></use></svg> Code Source du projet
        </a>
    </span>
</div>